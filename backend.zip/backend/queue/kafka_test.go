package queue

import "testing"

func TestQueue(t *testing.T) {
	t.Log(CreateVM(1, "aaaa"))
}
